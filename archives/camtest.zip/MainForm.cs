﻿using Core;
using DesktopClient.BotControl;
using DesktopClient.WebServer;
using Microsoft.Web.WebView2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DesktopClient
{
    public partial class MainForm : Form
    {
        private readonly WebView2 mBrowser;
        private IDispatcher mDispatcher;

        public MainForm()
        {
            InitializeComponent();
            mBrowser = new WebView2();
            mBrowser.Dock = DockStyle.Fill;
            Controls.Add(mBrowser);
        }

        private void MBrowser_CoreWebView2InitializationCompleted(object sender, Microsoft.Web.WebView2.Core.CoreWebView2InitializationCompletedEventArgs e)
        {
            LocalServer.Start(mDispatcher, (string error) =>
            {
                if (error != null)
                {
                    MessageBox.Show(error, "Error", MessageBoxButtons.OK);
                    Close();
                }
                else
                {
                    mBrowser.CoreWebView2.Navigate("http://localhost:9999/index.html");
                }
            });
        }

        private SerialPort mSerialPort;

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            mDispatcher = new DispatcherImpl(this);
            mBrowser.CoreWebView2InitializationCompleted += MBrowser_CoreWebView2InitializationCompleted;
            mBrowser.EnsureCoreWebView2Async();

            //TEST COM CONNECTION. TO BE REMOVED
            string[] ports = SerialPort.GetPortNames();
            if (ports.Length > 0)
            {
                mSerialPort = new SerialPort();
                mSerialPort.PortName = ports[0];
                mSerialPort.BaudRate = 115200;
                mSerialPort.DataBits = 8;
                mSerialPort.Parity = Parity.None;
                mSerialPort.StopBits = StopBits.One;
                mSerialPort.Handshake = Handshake.RequestToSend;
                mSerialPort.DtrEnable = true;
                mSerialPort.DataReceived += MSerialPort_DataReceived;
                mSerialPort.Open();
            }


            //TEST COM CONNECTION. TO BE REMOVED
            /*            string[] ports = SerialPort.GetPortNames();
                        if (ports.Length > 0)
                        {
                            BotMain bot = new BotMain(mDispatcher, "test");
                            ComConnection con = new ComConnection(mDispatcher);
                            con.SetPortName(ports[0]);
                            bot.SetConnection(con);
                            bot.OnModAdded += Bot_OnModAdded;
                            bot.IsAvailableChanged += Bot_IsAvailableChanged;
                            bot.RunningChanged += Bot_RunningChanged;
                            bot.Start();
                        }*/
        }

        byte[] serialBuffer = new byte[1024 * 1024];
        int sbi = 0;
        int cnt = 0;

        private delegate void SetImgD(Image img);

        private void SetImg(Image img)
        {
            mPictureBox.Image = img;
        }
        private void emitBuffer(int len)
        {
            MemoryStream mem = new MemoryStream(serialBuffer, 0, len);
            try
            {
                Image img = Bitmap.FromStream(mem);
                BeginInvoke(new SetImgD(SetImg), img);
            }
            catch
            {

            }
        }
        private void MSerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int toRead = mSerialPort.BytesToRead;
            if(sbi + toRead > serialBuffer.Length)
            {
                sbi = 0;
                cnt = 0;
            }
            int read = mSerialPort.Read(serialBuffer, sbi, toRead);
            int i = sbi;
            sbi += read;
            byte[] b = serialBuffer;
            int c = cnt;
            while(i <sbi)
            {
                byte cb = b[i];
                ++i;
                if(cb == 0xff)
                {
                    c++;
                    if(c == 4)
                    {
                        emitBuffer(i - 3);
                        Array.Copy(b, i, b, 0, sbi - i);
                        sbi -= i;
                        i = 0;
                        c = 0;
                    }
                }
                else
                {
                    c = 0;
                }
            }
            cnt = c;
        }

        private void Bot_RunningChanged(BotMain sender, bool running)
        {
            Debug.WriteLine("Bot_IsAvailableChanged");
        }

        private void Bot_IsAvailableChanged(ControlCore.IBot sender, bool isAvailable)
        {
            Debug.WriteLine("Bot_IsAvailableChanged");
        }

        private void Bot_OnModAdded(ControlCore.IBot sender, ControlCore.IMod mod)
        {
            Debug.WriteLine("Bot_OnModAdded");
            mod.OnModStateChanged += Mod_OnModStateChanged;
        }

        private void Mod_OnModStateChanged(ControlCore.IBot sender, ControlCore.IMod mod)
        {
            Debug.WriteLine("Mod_OnModStateChanged");
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            LocalServer.Stop();
        }
    }
}
