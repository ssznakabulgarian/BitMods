#ifndef _DEVICE_h
#define _DEVICE_h

#include "Base.h"

#define queueLength 64

#define hasLengthByte0 ( firstByte & B01000000 )
#define hasLengthByte1 ( firstByte & B00100000 )
extern byte bodyData[maxMessageSizeInBytes];
extern uint bodyDataIndex;
extern byte responseLength;
extern byte response[maxResponseSizeInBytes];

//methods
void InitializeDevice(uint32_t busProbePin, uint32_t busOutPin);
void ResetDevice();
void DeviceOnBusFalling();
void DeviceOnBusRising();
void ComputeResponse(byte command, uint messageDataLength, byte* messageData, byte& responseLength, byte* response);


#endif
