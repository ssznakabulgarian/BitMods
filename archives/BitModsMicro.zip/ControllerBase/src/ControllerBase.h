// Controller.h

#ifndef _Controller_h
#define _Controller_h

#include "Base.h"

//message characteristics
#define delayBeforeACK (maximumZeroCount - 1) * bitLength

class Device
{
public:
    bool hasOutput;
    uint type;
    byte address;
    Device()
    {
        hasOutput = false;
        type = 0;//TODO: define types
        address = 0;
    }
    Device(bool hasOutput, byte address, uint type)
    {
        this->address = address;
        this->hasOutput = hasOutput;
        this->type = type;
    }
};

void InitializeController(int busProbePin, int busOutPin);
void ControllerOnBusRising();
bool SendMessage(byte command, byte address, uint length, byte* data);
int GetDeviceInfo(byte address, Device* output);
int DiscoverDevice(Device* output);

#endif
